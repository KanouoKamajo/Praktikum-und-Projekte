package com.example.uml_lern_app

data class UnitItem(
    val title: String,
    val description: String,
    val duration: String // oder Int, z. B. Minuten
)
