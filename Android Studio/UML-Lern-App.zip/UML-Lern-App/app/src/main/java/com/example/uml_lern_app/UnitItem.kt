package com.example.uml_lern_app

// Repräsentiert eine Unit eines Kurses.
data class UnitItem(
    val id: String,
    val title: String
)
