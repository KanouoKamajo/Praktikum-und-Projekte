package com.example.uml_lern_app

data class Course(
    val id: String,
    val title: String,
    val subtitle: String,
    val iconRes: Int
)
