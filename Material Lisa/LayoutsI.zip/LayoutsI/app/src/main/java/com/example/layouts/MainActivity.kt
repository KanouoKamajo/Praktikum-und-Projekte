package com.example.layouts

import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.core.widget.doOnTextChanged
import com.google.android.material.button.MaterialButton


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        /* activity_main_linearlayout.xml */
        setContentView(R.layout.activity_main_linearlayout)
        //setContentView(programmatic_layout(this))
        //setContentView(programmatic_layout_generic(this))

        /* activity_main_framelayout.xml */
        /*
        setContentView(R.layout.activity_main_framelayout)
        val email = findViewById<EditText>(R.id.editTextEMail)
        val kennwort = findViewById<EditText>(R.id.editTextKennwort)
        val button = findViewById<Button>(R.id.button)

        val textWatcher = object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                //TODO("Not yet implemented")
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                //TODO("Not yet implemented")
            }

            override fun afterTextChanged(p0: Editable?) {
                if (!email.text.toString().equals("") && !kennwort.text.toString().equals("")) {
                    button.isEnabled = true
                } else {
                    button.isEnabled = false
                }
            }
        }

        email.addTextChangedListener(textWatcher)
        kennwort.addTextChangedListener(textWatcher)
        */

        /* activity_main_constraintlayout.xml */
        //setContentView(R.layout.activity_main_constraintlayout)
    }

    fun programmatic_layout(context: Context): View {

        val LinearLayout_root = LinearLayout(context)

        // LinearLayout_root.id = "LinearLayout_root" // nicht so einfach moeglich, da ID-Literale zur Compilezeit an Int-Werte gebunden werden
        LinearLayout_root.orientation = LinearLayout.VERTICAL
        val layoutParams_match_match = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT)
        LinearLayout_root.layoutParams = layoutParams_match_match

        val LinearLayout_sub1 = LinearLayout(context)
        LinearLayout_sub1.orientation = LinearLayout.HORIZONTAL
        val layoutParams_match_wrap = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)
        LinearLayout_sub1.layoutParams = layoutParams_match_wrap

        val LinearLayout_sub_sub1 = LinearLayout(context)
        LinearLayout_sub_sub1.orientation = LinearLayout.VERTICAL
        val layoutParams_match_wrap_05f = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT, 0.5f)
        LinearLayout_sub_sub1.layoutParams=layoutParams_match_wrap_05f

        val editTextPersonVorname = EditText(context)
        editTextPersonVorname.hint = "Vorname"
        editTextPersonVorname.layoutParams = layoutParams_match_wrap
        LinearLayout_sub_sub1.addView(editTextPersonVorname)

        val editTextPersonGeburtsdatum = EditText(context)
        editTextPersonGeburtsdatum.hint = "Geburtsdatum"
        editTextPersonGeburtsdatum.layoutParams = layoutParams_match_wrap
        LinearLayout_sub_sub1.addView(editTextPersonGeburtsdatum)

        val LinearLayout_sub_sub2 = LinearLayout(context)
        LinearLayout_sub_sub2.orientation = LinearLayout.VERTICAL
        LinearLayout_sub_sub2.layoutParams=layoutParams_match_wrap_05f

        val editTextPersonNachname = EditText(context)
        editTextPersonNachname.hint = "Nachname"
        editTextPersonNachname.layoutParams = layoutParams_match_wrap
        LinearLayout_sub_sub2.addView(editTextPersonNachname)

        val editTextPersonGeburtsort = EditText(context)
        editTextPersonGeburtsort.hint = "Geburtsort"
        editTextPersonGeburtsort.layoutParams = layoutParams_match_wrap
        LinearLayout_sub_sub2.addView(editTextPersonGeburtsort)

        LinearLayout_sub1.addView(LinearLayout_sub_sub1)
        LinearLayout_sub1.addView(LinearLayout_sub_sub2)
        LinearLayout_root.addView(LinearLayout_sub1)

        val LinearLayout_sub2 = LinearLayout(context)
        LinearLayout_sub2.orientation = LinearLayout.VERTICAL
        val layoutParams_match_match_1f = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        LinearLayout_sub2.layoutParams = layoutParams_match_match_1f

        val editTextPersonStrasse= EditText(context)
        editTextPersonStrasse.hint = "Straße"
        editTextPersonStrasse.layoutParams = layoutParams_match_match_1f
        LinearLayout_sub2.addView(editTextPersonStrasse)

        val editTextPersonStadt= EditText(context)
        editTextPersonStadt.hint = "Stadt"
        editTextPersonStadt.layoutParams = layoutParams_match_match_1f
        LinearLayout_sub2.addView(editTextPersonStadt)

        //val button = Button(context)
        val button = MaterialButton(context)
        button.text = "Absenden"
        button.layoutParams = layoutParams_match_wrap
        LinearLayout_sub2.addView(button)

        LinearLayout_root.addView(LinearLayout_sub2)

        val LinearLayout_sub3 = LinearLayout(context)
        LinearLayout_sub3.orientation = LinearLayout.HORIZONTAL
        val layoutParams_match_match_05f = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT, 0.5f)
        LinearLayout_sub3.layoutParams = layoutParams_match_match_05f
        LinearLayout_root.addView(LinearLayout_sub3)

        return LinearLayout_root
    }

    fun programmatic_layout_generic(context: Context): View {

        val LinearLayout_root = LinearLayout(context)
        LinearLayout_root.orientation = LinearLayout.VERTICAL

        for (i in 1..10) {

            val editTextPersonVorname = EditText(context)
            editTextPersonVorname.hint = "Vorname" + i
            val layoutParams_match_wrap = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)
            editTextPersonVorname.layoutParams = layoutParams_match_wrap
            LinearLayout_root.addView(editTextPersonVorname)

        }

        return LinearLayout_root
    }

}
