package com.codabee.lesbasiques

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Paint.Align
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Layout.Alignment
import android.view.View
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    lateinit var textView: TextView
    val color : Color = Color.valueOf(
        145 / 255F,
        145 / 255F,
        145 / 255F,
        1F
    )

    val color2 = Color.parseColor("#40826d")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textView = findViewById(R.id.mon_texte)
        textView.textSize = 30F
        //textView.textAlignment = View.TEXT_ALIGNMENT_TEXT_END
        val secondText: TextView = findViewById(R.id.second_text)
        secondText.text = "Mon second texte"
        textView.setBackgroundColor(color2)
    }

}