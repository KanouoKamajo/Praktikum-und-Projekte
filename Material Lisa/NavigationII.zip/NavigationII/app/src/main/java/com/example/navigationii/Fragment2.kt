package com.example.navigationii

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.navigation.NavOptions
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs

class Fragment2 : Fragment() {

    val args : Fragment2Args by navArgs()

    lateinit var textView : TextView

    var view_created_before = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        StackQueueUtil.printBackStack(findNavController(), "Fragment2")
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_2, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        textView = view.findViewById(R.id.textView2)
        textView.setText(args.parameter)
        if (!view_created_before) {
            fragment_calls(view)
            view_created_before = true
        }
    }

    private fun fragment_calls(view: View) {

        // Analog zu Navigation I
        // Source: https://androiddvlpr.com/android-intent-flags-everything-you-need-to-know/
        if (textView.text.toString().equals("Task A")) {
            val action = Fragment2Directions.actionFragment2Self("Task A1")
            // FragmentNavigation -> FragmentMain -> Fragment2 (A) -> Fragment2 (A1)
            findNavController().navigate(action)
        }

        if (textView.text.toString().equals("Task B")) {
            val action = Fragment2Directions.actionFragment2Self("Task B1")
            // analog "intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)"
            val navoptions = NavOptions.Builder().setPopUpTo(R.id.fragmentMain, false).build()
            // FragmentNavigation -> FragmentMain -> Fragment2 (B1)
            findNavController().navigate(action, navoptions)
        }

        if (textView.text.toString().equals("Task C")) {
            // Dummy Fragment on stack
            findNavController().navigate(R.id.fragment1)
            // The following line will not work, because Fragment2Directions can only applied if
            // fragment2 is on top of the back stack (not fragment1)
            // val action = Fragment2Directions.actionFragment2Self("Task C1")
            // analog "intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)"
            val navoptions = NavOptions.Builder().setPopUpTo(R.id.fragment1, false).build()
            // FragmentNavigation -> FragmentMain -> Fragment2 (C) -> Fragment1 (Neues Fragment) -> Fragment2 (C1)
            val args = Bundle()
            args.putString("parameter", "Task C1")
            findNavController().navigate(R.id.fragment2, args, navoptions)
        }

        if (textView.text.toString().equals("Task C1")) {
            // analog "intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)"
            val navoptions = NavOptions.Builder().setPopUpTo(R.id.fragment1, false).build()
            // FragmentNavigation -> FragmentMain -> Fragment2 (C) -> Fragment1 (Neues Fragment) -> Fragment2 (C2)
            val args = Bundle()
            args.putString("parameter", "Task C2")
            findNavController().navigate(R.id.fragment2, args, navoptions)
        }

        if (textView.text.toString().equals("Task D")) {
            val action = Fragment2Directions.actionFragment2Self("Task D1")
            val navoptions : NavOptions = NavOptions.Builder().setLaunchSingleTop(true).build()
            // analog "intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)"
            // FragmentNavigation, FragmentMain -> Fragment2 (D1)
            findNavController().navigate(action, navoptions)
        }

    }

}