package com.example.navigationii

import android.os.Bundle
import androidx.lifecycle.ViewModel

class CustomViewModel : ViewModel() {

    private var bundle: Bundle? = null

    fun getBundle () : Bundle? {
        return bundle
    }

    fun setBundle (bundle_arg : Bundle)  {
        bundle = bundle_arg
    }

}