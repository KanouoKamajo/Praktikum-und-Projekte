package com.example.navigationii

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import java.lang.reflect.InvocationTargetException

class FragmentMain : Fragment() {

    val args : FragmentMainArgs by navArgs()

    lateinit var editTextParameter11 : EditText
    lateinit var textViewReturn11 : TextView
    lateinit var editTextParameter21 : EditText
    lateinit var editTextParameter22 : EditText
    lateinit var textViewReturn12 : TextView

    var request_code : Int = 0

    override fun onDestroyView() {
        super.onDestroyView()
        onSaveInstanceState(Bundle())
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(R.id.editTextParameter11.toString(), editTextParameter11.text.toString())
        outState.putString(R.id.textViewReturn11.toString(), textViewReturn11.text.toString())
        outState.putString(R.id.editTextParameter21.toString(), editTextParameter21.text.toString())
        outState.putString(R.id.editTextParameter22.toString(), editTextParameter22.text.toString())
        outState.putString(R.id.textViewReturn12.toString(), textViewReturn12.text.toString())
        outState.putInt("request_code", request_code)
        val customViewModel = ViewModelProvider(requireActivity()).get(CustomViewModel::class.java)
        customViewModel.setBundle(outState)
    }

    private fun onRestoreInstanceState(savedInstanceState: Bundle?) {

        if (savedInstanceState != null) {
            editTextParameter11.setText(savedInstanceState.getString(R.id.editTextParameter11.toString()))
            editTextParameter21.setText(savedInstanceState.getString(R.id.editTextParameter21.toString()))
            editTextParameter22.setText(savedInstanceState.getString(R.id.editTextParameter22.toString()))
            request_code = savedInstanceState.getInt("request_code")
        }

        try {
            textViewReturn11.setText(args.name)
        } catch (e: InvocationTargetException) {
            if (savedInstanceState != null) {
                textViewReturn11.setText(savedInstanceState.getString(R.id.textViewReturn11.toString()))
            }
        }

        try {
            if (request_code == 4) textViewReturn12.setText(args.ergebnis.toString())
        } catch (e: InvocationTargetException) {
            if (savedInstanceState != null) {
                textViewReturn12.setText(savedInstanceState.getString(R.id.textViewReturn12.toString()))
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        StackQueueUtil.printBackStack(findNavController(), "FragmentMain")
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_main, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // savedInstanceState always null
        // findNavController().restoreState(savedInstanceState)
        val customViewModel = ViewModelProvider(requireActivity()).get(CustomViewModel::class.java)

        editTextParameter11 = view.findViewById<EditText>(R.id.editTextParameter11)
        textViewReturn11 = view.findViewById<TextView>(R.id.textViewReturn11)
        editTextParameter21 = view.findViewById<EditText>(R.id.editTextParameter21)
        editTextParameter22 = view.findViewById<EditText>(R.id.editTextParameter22)
        textViewReturn12 = view.findViewById<TextView>(R.id.textViewReturn12)

        onRestoreInstanceState(customViewModel.getBundle())

        val button1 = view.findViewById<Button>(R.id.button1)
        button1.setOnClickListener(object : View.OnClickListener {
            override fun onClick(p0: View?) {
                val action = FragmentMainDirections.actionFragmentMainToFragment1()
                findNavController().navigate(action)
            }
        })

        val button2 = view.findViewById<Button>(R.id.button2)
        button2.setOnClickListener(object : View.OnClickListener {
            override fun onClick(p0: View?) {
                val action =
                    FragmentMainDirections.actionFragmentMainToFragment2(editTextParameter11.text.toString())
                findNavController().navigate(action)
            }
        })

        val button3 = view.findViewById<Button>(R.id.button3)
        button3.setOnClickListener(object : View.OnClickListener {
            override fun onClick(p0: View?) {
                try {
                    val action =
                        FragmentMainDirections.actionFragmentMainToFragment3(args.ergebnis)
                    findNavController().navigate(action)
                } catch (e: InvocationTargetException) {
                    request_code = 3
                    val action =
                        FragmentMainDirections.actionFragmentMainToFragment3(0)
                    findNavController().navigate(action)
                }
            }
        })

        val button4 = view.findViewById<Button>(R.id.button4)
        button4.setOnClickListener(object : View.OnClickListener {
            override fun onClick(p0: View?) {
                try {
                    if (editTextParameter21.text.isNotEmpty() && editTextParameter22.text.isNotEmpty()) {
                        val parameter1 : Int = editTextParameter21.text.toString().toInt()
                        val parameter2 : Int = editTextParameter22.text.toString().toInt()
                        request_code = 4
                        try {
                            val action =
                                FragmentMainDirections.actionFragmentMainToFragment4(parameter1, parameter2, args.name)
                            findNavController().navigate(action)
                        } catch (e: InvocationTargetException) {
                            val action =
                                FragmentMainDirections.actionFragmentMainToFragment4(parameter1, parameter2, textViewReturn11.text.toString())
                            findNavController().navigate(action)
                        }
                    } else {
                        displayMessage(view.context, "Parameter 1 or 2 is not given")
                    }
                } catch (e : java.lang.NumberFormatException) {
                    displayMessage(view.context, "Parameter 1 or 2 is no valid Integer")
                }

            }
        })

        val button5 = view.findViewById<Button>(R.id.button5)
        button5.setOnClickListener(object : View.OnClickListener {
            override fun onClick(p0: View?) {
                val person : Person = Person ("John", "Doe")
                val action = FragmentMainDirections.actionFragmentMainToFragment5(person)
                findNavController().navigate(action)
            }
        })

    }

    private fun displayMessage(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
    }

}