package com.example.navigationii

import android.util.Log
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavController

class StackQueueUtil {

    companion object {

        fun printBackStack(navController: NavController, tag : String) {

            val bse_deque : ArrayDeque<NavBackStackEntry> = navController.backQueue

            val n : Int = bse_deque.size-1
            var backStack_String : String = "BackStack ["

            for (i in 0..n){
                val nbse : NavBackStackEntry = bse_deque.get(i)
                backStack_String = backStack_String + nbse.destination.label  + " (" + nbse +") "+ ", "
                //backStack_String = backStack_String + nbse.destination.label + ", "
            }
            backStack_String = backStack_String.subSequence(0, backStack_String.lastIndex-1) as String
            backStack_String = backStack_String + "]"
            Log.e(this.javaClass.name + " (" + tag + ")", backStack_String)

        }

    }

}