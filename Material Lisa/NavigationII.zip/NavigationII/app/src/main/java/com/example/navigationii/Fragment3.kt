package com.example.navigationii

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import android.widget.Button
import android.widget.EditText
import androidx.core.view.MenuProvider
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.navigation.NavDirections
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs

class Fragment3 : Fragment() {

    val args : Fragment3Args by navArgs()

    lateinit var editText : EditText

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Overwriting NavUp-Behaviour
        val menuProvider = object : MenuProvider {
            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
            }

            override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
                if (menuItem.itemId == android.R.id.home) {
                    val action: NavDirections = Fragment3Directions.actionFragment3ToFragmentMain(
                        editText.text.toString(),
                        args.ergebnis
                    )
                    findNavController().navigate(action)
                }
                return true
            }
        }

        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onResume(owner: LifecycleOwner) {
                super.onResume(owner)
                activity!!.addMenuProvider(menuProvider)
            }

            override fun onPause(owner: LifecycleOwner) {
                super.onPause(owner)
                activity!!.removeMenuProvider(menuProvider)
            }
        })

        StackQueueUtil.printBackStack(findNavController(), "Fragment3")
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_3, container, false)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val button = view.findViewById<Button>(R.id.button)
        editText = view.findViewById(R.id.editTextTextPersonName)
        button.setOnClickListener(object : View.OnClickListener {
            override fun onClick(p0: View?) {
                val action : NavDirections = Fragment3Directions.actionFragment3ToFragmentMain(editText.text.toString(), args.ergebnis)
                findNavController().navigate(action)
            }
        })
    }

}