package com.sqlitedemo

// Erstellunug einer Datenklasse
class EmpModelClass(val id: Int, val name: String, val email: String)
