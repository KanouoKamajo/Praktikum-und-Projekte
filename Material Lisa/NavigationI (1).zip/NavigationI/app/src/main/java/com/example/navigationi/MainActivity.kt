package com.example.navigationi

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.provider.ContactsContract
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date

class MainActivity : AppCompatActivity() {

    var photoFile: File? = null
    var mCurrentPhotoPath: String? = null

    var lauch_Activity_noparams_result: ActivityResultLauncher<*>? = null
    var lauch_Activity_params_result: ActivityResultLauncher<*>? = null
    var lauch_Activity_params_resultObject: ActivityResultLauncher<*>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TaskActivityStackUtil.printActivityStack("MainActivity onCreate()", this)
        setContentView(R.layout.activity_main)

        // Register in onCreate or onAttach
        // (LifecycleOwners must call register before they are STARTED)
        lauch_Activity_noparams_result = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult(),
            object : ActivityResultCallback<ActivityResult> {
                override fun onActivityResult(result: ActivityResult?) {
                    if (result!!.resultCode == Activity.RESULT_OK) {
                        val data : Intent? = result.data
                        // Data-type specific i. e. getCharSequenceExtra()
                        val result : String = data?.getCharSequenceExtra(Activity_noParams_result.RETURN_VALUE).toString()
                        val textview = findViewById<TextView>(R.id.textViewReturn11)
                        textview.text = result
                    }
                }
            }
        )

        lauch_Activity_params_result = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult(),
            object : ActivityResultCallback<ActivityResult> {
                override fun onActivityResult(result: ActivityResult?) {
                    if (result!!.resultCode == Activity.RESULT_OK) {
                        val data : Intent? = result.data
                        // Data-type specific i. e. getCharSequenceExtra()
                        val result : String = data?.getIntExtra(Activity_params_result.RETURN_VALUE,0).toString()
                        val textview = findViewById<TextView>(R.id.textViewReturn12)
                        textview.text = result
                    }
                }
            }
        )

        lauch_Activity_params_resultObject = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult(),
            object : ActivityResultCallback<ActivityResult> {
                override fun onActivityResult(result: ActivityResult?) {
                    //val myBitmap = BitmapFactory.decodeFile(photoFile!!.absolutePath)
                    //imageView.setImageBitmap(myBitmap)
                    val intent = Intent(applicationContext, DialogActivity::class.java)
                    intent.putExtra("path", photoFile!!.absolutePath)
                    startActivity(intent)
                }
            }
        )

        val button1 = findViewById<Button>(R.id.button1)
        button1.setOnClickListener(object : View.OnClickListener{
            override fun onClick(p0: View?) {
                val intent = Intent(applicationContext, Activity_noParams_noResult::class.java)
                /*
                val clazz  = Class.forName("com.example.navigationi.Activity_noParams_noResult")
                val intent = Intent(applicationContext, clazz)
                 */
                startActivity(intent)
                //finish()
            }
        })

        val button2 = findViewById<Button>(R.id.button2)
        button2.setOnClickListener(object : View.OnClickListener{
            override fun onClick(p0: View?) {
                val editText = findViewById<EditText>(R.id.editTextParameter11)
                val intent = Intent(applicationContext, Activity_params_noResult::class.java)
                intent.putExtra(R.id.editTextParameter11.toString(), editText.text.toString());
                startActivity(intent)
            }
        })

        val button3 = findViewById<Button>(R.id.button3)
        button3.setOnClickListener(object : View.OnClickListener{
            override fun onClick(p0: View?) {
                val intent = Intent(applicationContext, Activity_noParams_result::class.java)
                /* Deprecated
                startActivityForResult(intent,0);
                */
                (lauch_Activity_noparams_result as ActivityResultLauncher<Intent>).launch(intent);
            }
        })

        val button4 = findViewById<Button>(R.id.button4)
        button4.setOnClickListener(object : View.OnClickListener{
            override fun onClick(p0: View?) {
                val editTextParameter21 = findViewById<EditText>(R.id.editTextParameter21)
                val editTextParameter22 = findViewById<EditText>(R.id.editTextParameter22)
                val intent = Intent(applicationContext, Activity_params_result::class.java)

                try {
                    if (editTextParameter21.text.isNotEmpty() && editTextParameter22.text.isNotEmpty()) {
                        val parameter1 : Int = editTextParameter21.text.toString().toInt()
                        intent.putExtra(R.id.editTextParameter21.toString(), parameter1)
                        val parameter2 : Int = editTextParameter22.text.toString().toInt()
                        intent.putExtra(R.id.editTextParameter22.toString(), parameter2)
                        (lauch_Activity_params_result as ActivityResultLauncher<Intent>).launch(intent);
                    } else {
                        displayMessage(baseContext, "Parameter 1 or 2 is not given")
                    }
                } catch (e : java.lang.NumberFormatException) {
                    displayMessage(baseContext, "Parameter 1 or 2 is no valid Integer")
                }
            }
        })

        val button5 = findViewById<Button>(R.id.button5)
        button5.setOnClickListener(object : View.OnClickListener{
            override fun onClick(p0: View?) {
                val person : Person = Person ("John", "Doe")
                val intent = Intent(applicationContext, Activity_paramObject::class.java)
                intent.putExtra("object", person)
                startActivity(intent)
            }
        })

        val button6 = findViewById<Button>(R.id.button6)
        button6.setOnClickListener(object : View.OnClickListener{
            override fun onClick(p0: View?) {
                val intent = Intent(ContactsContract.Intents.Insert.ACTION)
                intent.type = ContactsContract.RawContacts.CONTENT_TYPE
                intent.putExtra(ContactsContract.Intents.Insert.NAME, "John Doe")
                intent.putExtra(ContactsContract.Intents.Insert.PHONE, "+49 69 4711 0815")
                startActivity(intent)
            }
        })

        val button7 = findViewById<Button>(R.id.button7)
        button7.setOnClickListener(object : View.OnClickListener{
            override fun onClick(p0: View?) {
                // Source: https://www.howtodoandroid.com/capture-image-android/
                captureImage()
            }
        })

    }

    override fun onResume(){
        super.onResume()
        TaskActivityStackUtil.printActivityStack("MainActivity onResume()", this)
    }

    override fun onStop(){
        super.onStop()
        TaskActivityStackUtil.printActivityStack("MainActivity onStop()", this)
    }

    override fun onDestroy() {
        super.onDestroy()
        TaskActivityStackUtil.printActivityStack("MainActivity onDestroy()", this)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 0) {
            captureImage();
        }
    }

    private fun captureImage() {

        if (ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    android.Manifest.permission.CAMERA
                ),
                0
            )

        } else {

            val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)

            if (takePictureIntent.resolveActivity(packageManager) != null) {
                // Create the File where the photo should go
                try {
                    photoFile = createImageFile()
                    // Continue only if the File was successfully created
                    if (photoFile != null) {
                        val photoURI = FileProvider.getUriForFile(
                            this,
                            "com.example.navigationi.fileprovider",
                            photoFile!!
                        )
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                        //startActivityForResult(takePictureIntent, CAPTURE_IMAGE_REQUEST)
                        (lauch_Activity_params_resultObject as ActivityResultLauncher<Intent>).launch(takePictureIntent);
                    }
                } catch (ex: Exception) {
                    // Error occurred while creating the File
                    displayMessage(baseContext, ex.message.toString())
                }

            } else {
                displayMessage(baseContext, "Null")
            }
        }

    }

    @Throws(IOException::class)
    private fun createImageFile(): File {
        // Create an image file name
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val imageFileName = "JPEG_" + timeStamp + "_"
        val storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        val image = File.createTempFile(
            imageFileName, /* prefix */
            ".jpg", /* suffix */
            storageDir      /* directory */
        )

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = image.absolutePath
        return image
    }

    private fun displayMessage(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
    }

    /*
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == CAPTURE_IMAGE_REQUEST && resultCode == Activity.RESULT_OK) {
            val myBitmap = BitmapFactory.decodeFile(photoFile!!.absolutePath)
            //imageView.setImageBitmap(myBitmap)
            val intent = Intent(applicationContext, DialogActivity::class.java)
            intent.putExtra("path", photoFile!!.absolutePath)
            startActivity(intent)
        } else {
            displayMessage(baseContext, "Request cancelled or something went wrong.")
        }
    }
    */

}