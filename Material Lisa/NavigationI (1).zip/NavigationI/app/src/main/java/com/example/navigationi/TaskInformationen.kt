package com.example.navigationi

class TaskInformationen {

    var taskId : Int = -1;

    var activityStack : MutableList<String> = mutableListOf<String>()

    constructor(ptaskId : Int ) {
        taskId = ptaskId
    }

    fun get_stack_size (): Int {
        return activityStack.size
    }

    fun push(id: Int, activity : String, position : Int) : Boolean {
        if (activityStack.size+1 == position && id == taskId) {
            activityStack.add(activity);
            return true;
        } else {
            return false;
        }
    }

    fun top_neq(arg : String?) : Boolean {
        if (activityStack.size>0 && arg != null) {
            return !activityStack.get(activityStack.size-1).equals(arg)
        } else {
            return false;
        }
    }

    fun pop(id: Int, position : Int) : Boolean {
        if (activityStack.size-1 == position && id == taskId) {
            activityStack.removeAt(activityStack.size-1)
            return true;
        } else {
            return false;
        }
    }

    fun print_activity_stack(): String {

        var ret : String  = "["

        val itr0 : Iterator<String> = activityStack.iterator()

        while (itr0.hasNext()){
            val item : String = itr0.next()
            ret = ret + item + ", "
        }

        if(ret.length> 1 ) {
            ret = ret.subSequence(0, ret.length-2) as String
        } else {
            ret = ret + "empty"
        }
        ret = ret + "]"

        return ret

    }
}