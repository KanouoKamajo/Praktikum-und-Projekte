package com.example.navigationi

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView

class Activity_params_noResult : AppCompatActivity() {

    lateinit var textView : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TaskActivityStackUtil.printActivityStack("Activity_params_noResult onCreate()", this)
        setContentView(R.layout.activity_params_no_result)

        if (intent.hasExtra(R.id.editTextParameter11.toString())) {
            val parameter1: String? = intent.getStringExtra(R.id.editTextParameter11.toString())
            textView = findViewById<TextView>(R.id.textView2)
            textView.setText(parameter1)
        }

        // Source: https://androiddvlpr.com/android-intent-flags-everything-you-need-to-know/
        if (textView.text.toString().equals("Task A")) {
            val intent = Intent(applicationContext, Activity_params_noResult::class.java)
            intent.putExtra(R.id.editTextParameter11.toString(), "Task A1");
            // MainActivity -> A -> A1
            startActivity(intent)
        }

        if (textView.text.toString().equals("Task B")) {
            val intent = Intent(applicationContext, Activity_params_noResult::class.java)
            intent.putExtra(R.id.editTextParameter11.toString(), "Task B1");
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            // B1
            startActivity(intent)
        }

        if (textView.text.toString().equals("Task C")) {
            val intent = Intent(applicationContext, Activity_params_noResult::class.java)
            intent.putExtra(R.id.editTextParameter11.toString(), "Task C1");
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            // MainActivity -> C1
            startActivity(intent)
        }

        if (textView.text.toString().equals("Task D")) {
            val intent = Intent(applicationContext, Activity_params_noResult::class.java)
            intent.putExtra(R.id.editTextParameter11.toString(), "Task D1");
            intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            // MainActivity -> D
            startActivity(intent)
        }

    }

    override fun onResume(){
        super.onResume()
        TaskActivityStackUtil.printActivityStack("Activity_params_noResult onResume()", this)
    }

    override fun onStop(){
        super.onStop()
        TaskActivityStackUtil.printActivityStack("Activity_params_noResult onStop()", this)
    }

    override fun onDestroy() {
        super.onDestroy()
        TaskActivityStackUtil.printActivityStack("Activity_params_noResult onDestroy()", this)
    }

}