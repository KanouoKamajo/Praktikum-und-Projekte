package com.example.navigationi

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText

class Activity_noParams_result : AppCompatActivity() {

    lateinit var editText : EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TaskActivityStackUtil.printActivityStack("Activity_noParams_result onCreate()", this)
        setContentView(R.layout.activity_no_params_result)
        editText = findViewById(R.id.editTextTextPersonName)

        val button = findViewById<Button>(R.id.button)
        button.setOnClickListener(object : View.OnClickListener{
            override fun onClick(p0: View?) {
                closeActivity()
            }
        })
    }

    fun closeActivity() {
        val intent : Intent = Intent()
        intent.putExtra(Companion.RETURN_VALUE, editText.text)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

    override fun onBackPressed() {
        closeActivity()
    }

    companion object {
        val RETURN_VALUE : String = "name"
    }

}