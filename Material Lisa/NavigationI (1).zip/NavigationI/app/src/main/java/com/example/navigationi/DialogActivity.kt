package com.example.navigationi

import android.app.Activity
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.Window
import android.widget.ImageView

class DialogActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TaskActivityStackUtil.printActivityStack("DialogActivity onCreate()", this)
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_dialog)

        if (intent.hasExtra("path")) {
            val path : String? = intent.getStringExtra("path")
            val myBitmap = BitmapFactory.decodeFile(path)
            val imageView = findViewById<ImageView>(R.id.imageView)
            imageView.setImageBitmap(myBitmap)
            imageView.rotation = 90.0f
        }

    }

}