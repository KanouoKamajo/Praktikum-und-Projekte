package com.example.navigationi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class Activity_paramObject : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TaskActivityStackUtil.printActivityStack("Activity_paramObject onCreate()", this)
        setContentView(R.layout.activity_param_object)

        if (intent.hasExtra("object")) {
            val person_object : Person = intent.getParcelableExtra("object", Person::class.java)!!
            val textView = findViewById<TextView>(R.id.textView6)
            textView.setText(person_object.vorname + " " + person_object.nachname)
        }

    }

}