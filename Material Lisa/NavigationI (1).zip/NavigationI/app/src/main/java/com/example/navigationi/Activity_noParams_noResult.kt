package com.example.navigationi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Activity_noParams_noResult : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TaskActivityStackUtil.printActivityStack("Activity_noParams_noResult onCreate()", this)
        setContentView(R.layout.activity_no_params_no_result)
    }

}