package com.example.navigationi

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView

class Activity_params_result : AppCompatActivity() {

    var result_value : Int = 0;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TaskActivityStackUtil.printActivityStack("Activity_params_result onCreate()", this)
        setContentView(R.layout.activity_params_result)

        var parameter1 = 0;
        var parameter2 = 0;

        val textView3 = findViewById<TextView>(R.id.textView3)
        if (intent.hasExtra(R.id.editTextParameter21.toString())) {
            parameter1 = intent.getIntExtra(R.id.editTextParameter21.toString(),0)
            textView3.setText(parameter1.toString())
        }

        val textView4 = findViewById<TextView>(R.id.textView4)
        if (intent.hasExtra(R.id.editTextParameter22.toString())) {
            parameter2 = intent.getIntExtra(R.id.editTextParameter22.toString(),0)
            textView4.setText(parameter2.toString())
        }

        result_value = parameter1 + parameter2

        val textView5  = findViewById<TextView>(R.id.textView5)
        textView5.setText(result_value.toString())

        val button = findViewById<Button>(R.id.button8)
        button.setOnClickListener(object : View.OnClickListener{
            override fun onClick(p0: View?) {
                closeActivity()
            }
        })

    }

    fun closeActivity() {
        val intent : Intent = Intent()
        intent.putExtra(Activity_params_result.RETURN_VALUE, result_value)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

    override fun onBackPressed() {
        closeActivity()
    }

    companion object {
        val RETURN_VALUE : String = "ergebnis"
    }
}