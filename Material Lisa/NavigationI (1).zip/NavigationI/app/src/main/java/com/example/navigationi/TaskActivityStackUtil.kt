package com.example.navigationi

import android.app.ActivityManager
import android.content.Context
import android.util.Log
import androidx.appcompat.app.AppCompatActivity

// adb shell dumpsys activity activities package com.example.navigationi
class TaskActivityStackUtil {

    companion object {

        var task_list: MutableList<TaskInformationen> = mutableListOf<TaskInformationen>()

        fun printActivityStack(tag : String, context: Context) {

            synchronize_activity_stack(context)

            val itr0 : Iterator<TaskInformationen> = task_list.iterator()

            while (itr0.hasNext()){
                val taskInformationen : TaskInformationen = itr0.next()
                //Log.e("ActivityStackUtil (" + tag + ")", "[src:"+ tag + " Task: " +  taskInformationen.taskId + ", Activity-Stack: " + taskInformationen.print_activity_stack() + "]")
                Log.e("ActivityStackUtil", "[Task: " +  taskInformationen.taskId + ", Activity-Stack: " + taskInformationen.print_activity_stack() + "]")
            }
        }

        private fun synchronize_activity_stack(context: Context) {

            synchronize_task_list(context)

            val am: ActivityManager =
                context.getSystemService(AppCompatActivity.ACTIVITY_SERVICE) as ActivityManager
            val app_task_list: List<ActivityManager.AppTask> = am.appTasks
            val itr0: Iterator<ActivityManager.AppTask> = app_task_list.listIterator()

            while (itr0.hasNext()) {
                val appTask: ActivityManager.AppTask = itr0.next()
                val task : TaskInformationen = task_list.filter { taskInformationen -> taskInformationen.taskId == appTask.taskInfo.taskId }.get(0)
                val stack_size = task.get_stack_size()

                if (stack_size < appTask.taskInfo.numActivities) {
                    // Pop element
                    task.push(appTask.taskInfo.taskId, appTask.taskInfo.topActivity?.shortClassName.toString(), appTask.taskInfo.numActivities)
                }
                if (stack_size > appTask.taskInfo.numActivities) {
                    // Push element
                    task.pop(appTask.taskInfo.taskId, appTask.taskInfo.numActivities)
                }
                if (stack_size == appTask.taskInfo.numActivities && task.top_neq(appTask.taskInfo.topActivity?.shortClassName.toString())){
                    // Pop-push situation (i.e. former activity was removed and new activity added stack_size between to prints not changed)
                    task.pop(appTask.taskInfo.taskId, appTask.taskInfo.numActivities-1)
                    task.push(appTask.taskInfo.taskId, appTask.taskInfo.topActivity?.shortClassName.toString(), appTask.taskInfo.numActivities)
                }
            }

        }

        private fun synchronize_task_list(context: Context) {

            val am: ActivityManager =
                context.getSystemService(AppCompatActivity.ACTIVITY_SERVICE) as ActivityManager
            val app_task_list: List<ActivityManager.AppTask> = am.appTasks
            val itr0: Iterator<ActivityManager.AppTask> = app_task_list.listIterator()
            val app_task_id_list0: MutableList<Int> = mutableListOf<Int>()

            while (itr0.hasNext()) {
                val appTask: ActivityManager.AppTask = itr0.next()
                app_task_id_list0.add(appTask.taskInfo.taskId)
            }

            // Remove disappeared tasks
            task_list.removeIf { taskinformationen ->
                !app_task_id_list0.contains(
                    taskinformationen.taskId
                )
            }

            val task_id_list1: MutableList<Int> = mutableListOf<Int>()
            val itr1: Iterator<TaskInformationen> = task_list.listIterator();

            while (itr1.hasNext()) {
                val taskInformation: TaskInformationen = itr1.next()
                task_id_list1.add(taskInformation.taskId)
            }

            // Remove already existing tasks from app_task_id_list0 -> resut: new tasks
            app_task_id_list0.removeIf { id -> task_id_list1.contains(id) }

            val itr2: Iterator<Int> = app_task_id_list0.listIterator()

            while (itr2.hasNext()) {
                task_list.add(TaskInformationen(itr2.next()))
            }

        }

    }

}