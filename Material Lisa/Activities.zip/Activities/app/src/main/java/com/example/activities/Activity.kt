package com.example.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView

class Activity : AppCompatActivity() {

    companion object {
        var counter : Int = 0
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_)
        val textView = findViewById<TextView>(R.id.textView2);
        textView.text = "Activity" + Activity.counter
        Activity.counter = Activity.counter - 1;
        Log.e("Activity", "counter = " + Activity.counter)
    }

    override fun onResume() {
        super.onResume()
        if (Activity.counter > 0) {
            val intent = Intent(applicationContext, Activity::class.java)
            startActivity(intent)
        }
    }

}