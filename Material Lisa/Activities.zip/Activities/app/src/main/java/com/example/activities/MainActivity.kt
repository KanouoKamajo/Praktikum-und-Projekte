package com.example.activities

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.View.OnClickListener
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    lateinit var textView : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textView = findViewById(R.id.textView)
        textView.text = textView.text.toString() + "onCreate()\n";
        Log.e("MainActivity", "onCreate")

        val button = findViewById<Button>(R.id.button)
        button.setOnClickListener(object : OnClickListener {
            override fun onClick(p0: View?) {
                textView.text = "";
            }

        })

        val button2 = findViewById<Button>(R.id.button2)

        button2.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Hallo")
            builder.setMessage("Kurze Unterbrechnung")
            builder.setPositiveButton("Ok", DialogInterface.OnClickListener { dialogInterface, i ->  })
            builder.show();
        };

        /*
        button2.setOnClickListener(object : OnClickListener {
            override fun onClick(p0: View?) {
            }
        })
        */

        val button3 = findViewById<Button>(R.id.button3)
        button3.setOnClickListener(object : OnClickListener {
            override fun onClick(p0: View?) {
                val intent = Intent(applicationContext, DialogActivity::class.java)
                startActivity(intent)
            }
        })

        val button4 = findViewById<Button>(R.id.button4)
        button4.setOnClickListener(object : OnClickListener {
            override fun onClick(p0: View?) {
                Activity.counter = 0;
                val intent = Intent(applicationContext, Activity::class.java)
                startActivity(intent)
            }
        })

        val button5 = findViewById<Button>(R.id.button5)
        button5.setOnClickListener(object : OnClickListener {
            override fun onClick(p0: View?) {
                Activity.counter = 0;
                val intent = Intent(applicationContext, Activity::class.java)
                startActivity(intent)
                finish();
            }
        })

        val button6 = findViewById<Button>(R.id.button6)
        button6.setOnClickListener(object : OnClickListener {
            override fun onClick(p0: View?) {
                Activity.counter = 5;
                val intent = Intent(applicationContext, Activity::class.java)
                startActivity(intent)
            }
        })

    }

    override fun onStart() {
        super.onStart()
        Log.e("MainActivity", "onStart")
        textView.text = textView.text.toString() + "onStart()\n"
    }

    override fun onResume() {
        super.onResume()
        Log.e("MainActivity", "onResume")
        textView.text = textView.text.toString() + "onResume()\n"
    }

    override fun onPause() {
        super.onPause()
        Log.e("MainActivity", "onPause")
        textView.text = textView.text.toString() + "onPause()\n"
    }

    override fun onStop() {
        super.onStop()
        Log.e("MainActivity", "onStop")
        textView.text = textView.text.toString() + "onStop()\n"
    }

    override fun onRestart() {
        super.onRestart()
        Log.e("MainActivity", "onRestart")
        textView.text = textView.text.toString() + "onRestart()\n"
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.e("MainActivity", "onDestroy")
        textView.text = textView.text.toString() + "onDestroy()\n"
    }

    // NOT: override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(R.id.textView.toString(), textView.text.toString())
    }

    // Called after onCreate() (savedInstanceState same as in onCreate() - but not null)
    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        textView.setText(savedInstanceState.getString(R.id.textView.toString()))
    }
}